<?php
declare(strict_types=1);
define('ADMIN_PASSWORD', 'admin123'); // Поменяйте пароль здесь
/* База холста (ширина — фиксированная), высоту можно менять модулем */
if (!defined('CANVAS_W')) define('CANVAS_W', 1200);
if (!defined('CANVAS_H')) define('CANVAS_H', 10000); // по умолчанию