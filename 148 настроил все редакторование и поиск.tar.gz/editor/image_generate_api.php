<?php
/**
 * Image generation endpoint for GPT Image (gpt-image-1)
 * FIX: читаем ключ из SQLite: dirname(__DIR__) . '/data/zerro_blog.db',
 *      таблица text_beautify_settings (key/value) — как в text_beautify_api.php;
 *      + fallback на ENV OPENAI_API_KEY.
 *      Убран response_format; обработка b64_json/URL; сняты таймауты.
 */
header('Content-Type: application/json; charset=utf-8');

@set_time_limit(0);
@ini_set('max_execution_time', '0');
@ini_set('memory_limit', '-1');
date_default_timezone_set('UTC');

/** Вспомогательно: читаем JSON-тело, если пришло */
function read_json_body(): array {
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $j = json_decode($raw, true);
    return is_array($j) ? $j : [];
}

/** Берём OpenAI API key: сначала из ENV, затем из SQLite как в модуле стилизации */
function get_openai_key(): string {
    $apiKey = getenv('OPENAI_API_KEY');
    if ($apiKey) return $apiKey;

    try {
        $dbPath = dirname(__DIR__) . '/data/zerro_blog.db';
        $pdo = new PDO('sqlite:' . $dbPath);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        // На всякий случай создаём таблицу, как в text_beautify_api.php
        $pdo->exec("CREATE TABLE IF NOT EXISTS text_beautify_settings (
            key TEXT PRIMARY KEY,
            value TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )");
        $stmt = $pdo->query("SELECT value FROM text_beautify_settings WHERE key='openai_token' LIMIT 1");
        $val = $stmt ? (string)$stmt->fetchColumn() : '';
        return $val ?: '';
    } catch (Throwable $e) {
        return '';
    }
}

$in = read_json_body();
$prompt  = trim($_POST['prompt']  ?? $in['prompt']  ?? '');
// ПРИМЕЧАНИЕ: принимаем и 'context', и 'article' (как в твоём фронте):
$context = trim($_POST['context'] ?? $in['context'] ?? $_POST['article'] ?? $in['article'] ?? '');
$size    = trim($_POST['size']    ?? $in['size']    ?? '1024x1024');

if ($prompt === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Пустой prompt для генерации изображения']);
    exit;
}

/** Разрешённые размеры */
$allowedSizes = ['1024x1024','1024x1792','1792x1024','512x512','256x256'];
if (!in_array($size, $allowedSizes, true)) $size = '1024x1024';

/** Ключ */
$apiKey = get_openai_key();
if (!$apiKey) {
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'OpenAI API key не найден. Заполните его в настройках стилизации или задайте через переменную окружения OPENAI_API_KEY.']);
    exit;
}

/** Комбинируем prompt + контекст (необязательно) */
$fullPrompt = $prompt;
if ($context !== '') {
    $fullPrompt .= "\n\nContext:\n" . mb_substr($context, 0, 6000);
}

/** === 1) Генерация изображения (Images API) === */
$imgPayload = [
    'model'  => 'gpt-image-1',
    'prompt' => $fullPrompt,
    'size'   => $size,
    'n'      => 1
];

$ch = curl_init('https://api.openai.com/v1/images/generations');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    ],
    CURLOPT_POSTFIELDS     => json_encode($imgPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    CURLOPT_CONNECTTIMEOUT => 0,
    CURLOPT_TIMEOUT        => 0,
]);

$out = curl_exec($ch);
if ($out === false) {
    $err = curl_error($ch);
    curl_close($ch);
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>"Ошибка сети cURL: $err"]);
    exit;
}
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$resp = json_decode($out, true);
if ($httpCode >= 400 || isset($resp['error'])) {
    $msg = $resp['error']['message'] ?? "HTTP $httpCode";
    echo json_encode([
        'ok' => false,
        'error' => "OpenAI Images HTTP $httpCode: $msg",
        'raw' => $resp
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Достаём байты изображения */
$imageBytes = null;
if (!empty($resp['data'][0]['b64_json'])) {
    $imageBytes = base64_decode($resp['data'][0]['b64_json']);
} elseif (!empty($resp['data'][0]['url'])) {
    $imgUrl = $resp['data'][0]['url'];
    $ch2 = curl_init($imgUrl);
    curl_setopt_array($ch2, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 0,
        CURLOPT_TIMEOUT        => 0,
    ]);
    $imageBytes = curl_exec($ch2);
    curl_close($ch2);
}
if (!$imageBytes) {
    echo json_encode(['ok'=>false,'error'=>'Не удалось получить данные изображения из ответа', 'raw'=>$resp], JSON_UNESCAPED_UNICODE);
    exit;
}

/** Сохраняем PNG */
$saveDir = __DIR__ . '/uploads/gpt-images';
if (!is_dir($saveDir)) @mkdir($saveDir, 0775, true);

$filename = 'gptimg_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.png';
$filepath = $saveDir . '/' . $filename;
file_put_contents($filepath, $imageBytes);

$fileUrl = '/editor/uploads/gpt-images/' . $filename;

/** === 2) Генерируем alt и caption через чат-модель === */
$alt = '';
$caption = '';
try {
    $messages = [
        ['role' => 'system', 'content' =>
            'Ты пишешь лаконичные подписи к изображениям для статей. ' .
            'Верни строго JSON с полями: alt (до 120 символов) и caption (до 160 символов). ' .
            'Без комментариев и пояснений.'
        ],
        ['role' => 'user', 'content' =>
            "Описание изображения: " . $prompt . "\n" .
            "Фрагмент статьи: " . mb_substr($context, 0, 2000)
        ]
    ];
    $chatPayload = [
        'model' => 'gpt-4o-mini',
        'messages' => $messages,
        'temperature' => 0.3
    ];

    $ch3 = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch3, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey
        ],
        CURLOPT_POSTFIELDS     => json_encode($chatPayload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
        CURLOPT_CONNECTTIMEOUT => 0,
        CURLOPT_TIMEOUT        => 0,
    ]);
    $out2 = curl_exec($ch3);
    curl_close($ch3);

    if ($out2 !== false) {
        $r2 = json_decode($out2, true);
        $text = $r2['choices'][0]['message']['content'] ?? '';
        if ($text) {
            $start = strpos($text, '{');
            $end   = strrpos($text, '}');
            if ($start !== false && $end !== false && $end > $start) {
                $json = substr($text, $start, $end - $start + 1);
                $obj = json_decode($json, true);
                if (is_array($obj)) {
                    $alt     = trim($obj['alt'] ?? '');
                    $caption = trim($obj['caption'] ?? '');
                }
            }
        }
    }
} catch (Throwable $e) {
    /* ignore */
}
if ($alt === '')     $alt = mb_substr($prompt, 0, 120);
if ($caption === '') $caption = 'Иллюстрация по теме статьи';

/** HTML для вставки */
$html = '<figure class="tb-image">' .
          '<img src="' . $fileUrl . '" alt="' . htmlspecialchars($alt, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8') . '">' .
          '<figcaption>' . htmlspecialchars($caption, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8') . '</figcaption>' .
        '</figure>';

echo json_encode([
    'ok'      => true,
    'url'     => $fileUrl,
    'alt'     => $alt,
    'caption' => $caption,
    'html'    => $html
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
