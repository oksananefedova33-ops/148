<?php
// /editor/migrations/001_text_beautify.php
// Запустить ОДИН РАЗ через браузер: /editor/migrations/001_text_beautify.php

declare(strict_types=1);

$db = dirname(dirname(__DIR__)) . '/data/zerro_blog.db';
$pdo = new PDO('sqlite:' . $db);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "<pre>";
echo "🚀 Миграция: Text Beautify Module\n\n";

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS text_beautify_settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");
    
    echo "✅ Таблица text_beautify_settings создана\n";
    echo "\n✨ Миграция завершена успешно!\n";
    echo "\n📝 Теперь можно:\n";
    echo "   1. Открыть редактор\n";
    echo "   2. Создать текстовый элемент\n";
    echo "   3. Нажать кнопку '✨ Обернуть'\n";
    echo "   4. Выбрать стиль из пресетов\n";
    echo "   5. Для GPT: нажать ⚙️ и добавить токен OpenAI\n";
    
} catch (Exception $e) {
    echo "❌ Ошибка: " . $e->getMessage() . "\n";
}

echo "</pre>";