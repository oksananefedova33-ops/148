<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

// Долгие запросы к GPT
@set_time_limit(0);
@ini_set('max_execution_time', '0');
@ini_set('memory_limit', '-1');

$db = dirname(__DIR__) . '/data/zerro_blog.db';
$pdo = new PDO('sqlite:' . $db);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Создаем таблицу настроек если её нет
ensureSchema($pdo);

$action = $_REQUEST['action'] ?? '';

switch ($action) {
    
    case 'saveToken': {
        $token = trim($_POST['token'] ?? '');
        if (!$token) {
            echo json_encode(['ok' => false, 'error' => 'Токен не указан']);
            break;
        }
        
        $stmt = $pdo->prepare("INSERT OR REPLACE INTO text_beautify_settings (key, value) VALUES ('openai_token', ?)");
        $stmt->execute([$token]);
        
        echo json_encode(['ok' => true]);
        break;
    }
    
    case 'getToken': {
        $token = (string)($pdo->query("SELECT value FROM text_beautify_settings WHERE key='openai_token'")->fetchColumn() ?: '');
        echo json_encode(['ok' => true, 'token' => $token]);
        break;
    }
    
    case 'deleteToken': {
        $pdo->prepare("DELETE FROM text_beautify_settings WHERE key='openai_token'")->execute();
        echo json_encode(['ok' => true]);
        break;
    }
    
    case 'beautify': {
        $html = trim($_POST['html'] ?? '');
        $style = trim($_POST['style'] ?? 'modern');
        
        if (!$html) {
            echo json_encode(['ok' => false, 'error' => 'Текст не указан']);
            break;
        }
        
        // Получаем токен
        $token = (string)($pdo->query("SELECT value FROM text_beautify_settings WHERE key='openai_token'")->fetchColumn() ?: '');
        if (!$token) {
            echo json_encode(['ok' => false, 'error' => 'Токен OpenAI не настроен']);
            break;
        }
        
        // Формируем промпт в зависимости от стиля
         $prompts = [
            'modern' => 'Transform this HTML into a modern, clean design with gradients, shadows, and proper spacing. Use vibrant colors and contemporary UI patterns.',
            'elegant' => 'Transform this HTML into an elegant, sophisticated design with subtle colors, refined typography, and tasteful accents. Focus on minimalism and class.',
            'creative' => 'Transform this HTML into a bold, creative design with unique layouts, eye-catching colors, and innovative visual elements. Be daring and artistic.',
            'neon' => 'Transform this HTML into a cyberpunk neon design with glowing effects, dark backgrounds, electric colors (cyan, magenta, yellow), and futuristic aesthetic. Use box-shadows for glow effects.',
            'glass' => 'Transform this HTML into a glassmorphism design with frosted glass effects using backdrop-filter blur, subtle borders, soft shadows, and light/transparent backgrounds. Create depth with layering.',
            'gradient' => 'Transform this HTML into a gradient-heavy design with colorful overlays, smooth color transitions, and vibrant multi-color schemes. Use bold linear and radial gradients throughout.',
            'minimal' => 'Transform this HTML into an ultra-minimal design with maximum whitespace, monochrome colors (black/white/gray), subtle accents, and clean typography. Less is more.',
            'retro' => 'Transform this HTML into a retro 80s/90s design with bright neon colors, geometric shapes, bold patterns, pixel-perfect borders, and nostalgic aesthetic.',
            'crypto' => 'Transform this HTML into a cryptocurrency-themed design with dark backgrounds, blue/gold/green accents, tech-inspired elements, and professional financial aesthetic. Use blockchain-inspired patterns.',
            'corporate' => 'Transform this HTML into a professional corporate design with blue/gray color scheme, clean layouts, business-appropriate typography, and trust-building visual elements.',
            'playful' => 'Transform this HTML into a playful, fun design with rounded corners, pastel colors, cheerful elements, bouncy animations (via transform), and friendly aesthetic.',
            'luxe' => 'Transform this HTML into a luxury premium design with rich colors (gold, black, deep purple), elegant typography, sophisticated spacing, and high-end visual treatment.',
            'tech' => 'Transform this HTML into a tech/SaaS design with blues and purples, modern UI elements, sharp edges, tech-inspired iconography, and innovative aesthetic.'
        ];;
        
        $stylePrompt = $prompts[$style] ?? $prompts['modern'];
        
        $systemPrompt = "You are a professional web designer. Transform HTML into beautifully styled content using ONLY inline styles.

STRICT RULES:
1. Use ONLY inline style=\"\" attributes (no <style> tags, no CSS classes)
2. Apply modern design: gradients, shadows, rounded corners, proper spacing
3. Use semantic colors and ensure high contrast for readability
4. Use rem/em units where appropriate for responsiveness
5. Return ONLY the styled HTML, no explanations or markdown
6. Preserve all original text content exactly as provided
7. Keep the structure clean and semantic

DESIGN STYLE:
{$stylePrompt}";

        $userPrompt = "Transform this HTML:\n\n{$html}";
        
        // Вызов OpenAI API
        try {
            $result = callOpenAI($token, $systemPrompt, $userPrompt);
            
            if ($result['ok']) {
                echo json_encode([
                    'ok' => true,
                    'beautified' => $result['content']
                ]);
            } else {
                echo json_encode([
                    'ok' => false,
                    'error' => $result['error']
                ]);
            }
        } catch (Exception $e) {
            echo json_encode([
                'ok' => false,
                'error' => 'Ошибка запроса к OpenAI: ' . $e->getMessage()
            ]);
        }
        
        break;
    }
    
    default:
        echo json_encode(['ok' => false, 'error' => 'Unknown action']);
        break;
}

/* ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==================== */

function ensureSchema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS text_beautify_settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )");
}

function callOpenAI(string $token, string $systemPrompt, string $userPrompt): array {
    $url = 'https://api.openai.com/v1/chat/completions';
    
    
    // Estimate output tokens based on input length; allow large outputs
    $approxTokens = (int)ceil(strlen($userPrompt) / 3);
    $maxTokens = max(4096, min(16000, (int)ceil($approxTokens * 1.3))); // cap at 16k for safety
$data = [
        'model' => 'gpt-4o-mini', // Быстрая и дешевая модель
        'messages' => [
            [
                'role' => 'system',
                'content' => $systemPrompt
            ],
            [
                'role' => 'user',
                'content' => $userPrompt
            ]
        ],
        'temperature' => 0.7,
        'max_tokens' => $maxTokens
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $token
    ]);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 0);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['ok' => false, 'error' => 'Ошибка сети: ' . $error];
    }
    
    if ($httpCode !== 200) {
        $errorData = json_decode($response, true);
        $errorMsg = $errorData['error']['message'] ?? 'HTTP ' . $httpCode;
        return ['ok' => false, 'error' => $errorMsg];
    }
    
    $result = json_decode($response, true);
    
    if (!isset($result['choices'][0]['message']['content'])) {
        return ['ok' => false, 'error' => 'Неверный формат ответа от OpenAI'];
    }
    
    $content = $result['choices'][0]['message']['content'];
    
    // Очищаем от markdown если есть
    $content = preg_replace('/^```html\s*/i', '', $content);
    $content = preg_replace('/\s*```$/i', '', $content);
    $content = trim($content);
    
    return ['ok' => true, 'content' => $content];
}