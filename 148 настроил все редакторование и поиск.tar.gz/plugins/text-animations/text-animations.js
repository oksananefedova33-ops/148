/* === Text Animations: JS (плагин мини-редактора) ===
 * Добавляет кнопку "Анимация" в тулбар мини-редактора и применяет
 * классы .ta-appear / .ta-blink / .ta-colorcycle к выделенному тексту.
 *
 * Работает с любым contenteditable-редактором.
 * — Авто-поиск тулбара: .mini-toolbar, .wysiwyg-toolbar, [data-mini-editor-toolbar]
 * — Или установите вручную: TextAnimations.install(toolbarElement, { editorRoot })
 *
 * Сохранение/экспорт: анимации — это классы на <span>, поэтому они остаются в HTML.
 */

(function (global) {
  'use strict';

  const ANIM_CLASSES = ['ta-appear', 'ta-blink', 'ta-colorcycle'];
  const SELECTOR_TOOLBAR_CANDIDATES = [
    '[data-mini-editor-toolbar]',
    '.mini-toolbar',
    '.miniEditor-toolbar',
    '.wysiwyg-toolbar',
    '.editor-toolbar'
  ];

  // ======== Утилиты выбора/редактирования HTML ========

  function getCurrentEditableRoot() {
    const sel = window.getSelection && window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    const range = sel.getRangeAt(0);
    let node = range.commonAncestorContainer;
    if (node && node.nodeType === 3) node = node.parentNode;
    while (node && node !== document && node.nodeType === 1) {
      if (node.getAttribute && node.getAttribute('contenteditable') === 'true') {
        return node;
      }
      node = node.parentNode;
    }
    return null;
  }

  function selectionIsInside(element) {
    const sel = window.getSelection && window.getSelection();
    if (!sel || sel.rangeCount === 0) return false;
    const range = sel.getRangeAt(0);
    const container = range.commonAncestorContainer.nodeType === 3
      ? range.commonAncestorContainer.parentNode
      : range.commonAncestorContainer;
    return element && container && element.contains(container);
  }

  // Возвращает HTML выделения (или пустую строку)
  function getSelectedHTML() {
    const sel = window.getSelection && window.getSelection();
    if (!sel || sel.rangeCount === 0) return '';
    const div = document.createElement('div');
    for (let i = 0; i < sel.rangeCount; i++) {
      div.appendChild(sel.getRangeAt(i).cloneContents());
    }
    return div.innerHTML;
  }

  // Заменяет выделение заданным HTML
  function replaceSelectionWithHTML(html) {
    const sel = window.getSelection && window.getSelection();
    if (!sel || sel.rangeCount === 0) return;

    try {
      // Старый, но широко поддерживаемый и удобный метод.
      document.execCommand('insertHTML', false, html);
    } catch (e) {
      // Фоллбэк через Range
      const range = sel.getRangeAt(0);
      range.deleteContents();
      const frag = range.createContextualFragment(html);
      range.insertNode(frag);
      sel.removeAllRanges();
    }
  }

  // Оборачивает выделение в <span class="ta ...">
  function applyAnimation(className) {
    const editor = getCurrentEditableRoot();
    if (!editor || !selectionIsInside(editor)) return;

    const html = getSelectedHTML();
    if (!html || !html.trim()) return;

    const wrapped = `<span class="ta ${className}" data-ta="${className}">${html}</span>`;
    replaceSelectionWithHTML(wrapped);
  }

  // Снять анимацию: разворачиваем span.ta внутри выделения (или всего редактора, если выделение пустое)
  function removeAnimation() {
    const editor = getCurrentEditableRoot();
    if (!editor) return;

    const sel = window.getSelection && window.getSelection();
    let scope = editor;
    if (sel && sel.rangeCount) {
      const range = sel.getRangeAt(0);
      const container = range.commonAncestorContainer.nodeType === 3
        ? range.commonAncestorContainer.parentNode
        : range.commonAncestorContainer;
      if (editor.contains(container)) scope = container;
    }

    const targets = scope.querySelectorAll('span.ta');
    targets.forEach(span => {
      // Если span полностью внутри выделения — разворачиваем
      const p = span.parentNode;
      while (span.firstChild) p.insertBefore(span.firstChild, span);
      p.removeChild(span);
    });
  }

  // ======== UI: кнопка + меню ========

  function createButton(iconText, title) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'ta-ui-btn';
    btn.title = title;
    btn.textContent = iconText; // например, ✨
    return btn;
  }

  function createPopover(items) {
    const pop = document.createElement('div');
    pop.className = 'ta-ui-popover';
    pop.style.display = 'none';

    items.forEach(it => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'ta-ui-item';
      b.innerHTML = it.html;
      b.addEventListener('click', () => {
        it.onClick();
        hide();
      });
      pop.appendChild(b);
    });

    function show(anchorEl) {
      const r = anchorEl.getBoundingClientRect();
      pop.style.left = `${r.left + window.scrollX}px`;
      pop.style.top  = `${r.bottom + window.scrollY + 6}px`;
      pop.style.display = 'block';
      setTimeout(() => document.addEventListener('mousedown', onDocDown), 0);
    }
    function hide() {
      pop.style.display = 'none';
      document.removeEventListener('mousedown', onDocDown);
    }
    function onDocDown(e) {
      if (!pop.contains(e.target)) hide();
    }

    return { el: pop, show, hide };
  }

  function installIntoToolbar(toolbarEl, opts = {}) {
    if (!toolbarEl || toolbarEl.__taInstalled) return;
    toolbarEl.__taInstalled = true;

    // определим editorRoot (контент с contenteditable)
    let editorRoot = opts.editorRoot || null;
    if (!editorRoot) {
      // ближайший contenteditable к тулбару
      editorRoot = toolbarEl.closest('[data-editor-root]') ||
                   toolbarEl.parentElement?.querySelector('[contenteditable="true"]') ||
                   document.querySelector('[contenteditable="true"]');
    }

    // Кнопка
    const btn = createButton('✨', 'Анимация текста');
    toolbarEl.appendChild(btn);

    // Меню
    const menu = createPopover([
      {
        html: 'Появление <span class="ta-ui-kbd">A</span>',
        onClick: () => applyAnimation('ta-appear')
      },
      {
        html: 'Мерцание <span class="ta-ui-kbd">B</span>',
        onClick: () => applyAnimation('ta-blink')
      },
      {
        html: 'Мигание цвета <span class="ta-ui-kbd">C</span>',
        onClick: () => applyAnimation('ta-colorcycle')
      },
      {
        html: 'Снять анимацию <span class="ta-ui-kbd">Del</span>',
        onClick: () => removeAnimation()
      }
    ]);
    document.body.appendChild(menu.el);

    btn.addEventListener('click', () => {
      if (menu.el.style.display === 'block') menu.hide();
      else menu.show(btn);
    });

    // Горячие клавиши, пока фокус в editorRoot
    function onKey(e) {
      if (!editorRoot || !selectionIsInside(editorRoot)) return;
      // Alt+Shift+[A|B|C|D] — чтобы не конфликтовать с базовыми шорткатами
      if (e.altKey && e.shiftKey) {
        const key = e.key?.toLowerCase();
        if (key === 'a') { applyAnimation('ta-appear'); e.preventDefault(); }
        else if (key === 'b') { applyAnimation('ta-blink'); e.preventDefault(); }
        else if (key === 'c') { applyAnimation('ta-colorcycle'); e.preventDefault(); }
        else if (key === 'd' || e.key === 'Delete') { removeAnimation(); e.preventDefault(); }
      }
    }
    document.addEventListener('keydown', onKey);

    // Публичное API для отписки (если тулбар уничтожается)
    toolbarEl.__taDispose = () => {
      document.removeEventListener('keydown', onKey);
      menu.el.remove();
    };
  }

  // Авто-поиск тулбаров, если разработчик не вызвал install явно
  function autoInstall() {
    const found = SELECTOR_TOOLBAR_CANDIDATES
      .map(sel => Array.from(document.querySelectorAll(sel)))
      .flat();

    found.forEach(tb => installIntoToolbar(tb));

    // На случай динамического появления тулбаров (переинициализация редактора)
    const mo = new MutationObserver((muts) => {
      muts.forEach(m => {
        m.addedNodes && m.addedNodes.forEach(node => {
          if (!(node instanceof HTMLElement)) return;
          if (SELECTOR_TOOLBAR_CANDIDATES.some(sel => node.matches(sel))) {
            installIntoToolbar(node);
          }
          SELECTOR_TOOLBAR_CANDIDATES.forEach(sel => {
            node.querySelectorAll?.(sel).forEach(el => installIntoToolbar(el));
          });
        });
      });
    });
    mo.observe(document.documentElement, { childList: true, subtree: true });
  }

  // Публичное API
  const TextAnimations = {
    install(toolbarElement, options) { installIntoToolbar(toolbarElement, options); },
    removeFrom(toolbarElement) {
      toolbarElement?.__taDispose?.();
      toolbarElement && (toolbarElement.__taInstalled = false);
    },
    // на случай если хотите просто добавить CSS (например при экспорте)
    ensureCssLinked() {
      const id = 'text-animations-css-link';
      if (document.getElementById(id)) return;
      const link = document.createElement('link');
      link.id = id;
      link.rel = 'stylesheet';
      link.href = (window.TA_CSS_PATH || '/plugins/text-animations/text-animations.css');
      document.head.appendChild(link);
    }
  };

  // Экспорт в глобал
  global.TextAnimations = TextAnimations;

  // По умолчанию: подключаем CSS и автоподключение к тулбарам
  TextAnimations.ensureCssLinked();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autoInstall, { once: true });
  } else {
    autoInstall();
  }

})(window);
