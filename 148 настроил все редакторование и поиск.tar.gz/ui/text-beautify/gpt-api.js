// /ui/text-beautify/gpt-api.js
// Клиентская часть для работы с GPT API

window.TextBeautifyGPT = {
  
  // Проверка наличия токена
  async hasToken() {
    try {
      const r = await fetch('/editor/text_beautify_api.php?action=getToken', {
        cache: 'no-store'
      });
      const j = await r.json();
      return j.ok && j.token && j.token.length > 0;
    } catch(e) {
      return false;
    }
  },
  
  // Сохранить токен
  async saveToken(token) {
    const fd = new FormData();
    fd.append('action', 'saveToken');
    fd.append('token', token);
    
    try {
      const r = await fetch('/editor/text_beautify_api.php', {
        method: 'POST',
        body: fd
      });
      const j = await r.json();
      return j.ok;
    } catch(e) {
      console.error('Ошибка сохранения токена:', e);
      return false;
    }
  },
  
  // Удалить токен
  async deleteToken() {
    const fd = new FormData();
    fd.append('action', 'deleteToken');
    
    try {
      const r = await fetch('/editor/text_beautify_api.php', {
        method: 'POST',
        body: fd
      });
      const j = await r.json();
      return j.ok;
    } catch(e) {
      console.error('Ошибка удаления токена:', e);
      return false;
    }
  },
  
  // Стилизовать текст через GPT
  async beautify(html, style = 'modern') {
    const fd = new FormData();
    fd.append('action', 'beautify');
    fd.append('html', html);
    fd.append('style', style);
    
    try {
      const r = await fetch('/editor/text_beautify_api.php', {
        method: 'POST',
        body: fd
      });
      const j = await r.json();
      
      if (j.ok && j.beautified) {
        return { ok: true, html: j.beautified };
      } else {
        return { ok: false, error: j.error || 'Неизвестная ошибка' };
      }
    } catch(e) {
      console.error('Ошибка beautify:', e);
      return { ok: false, error: 'Ошибка запроса' };
    }
  }
  
};