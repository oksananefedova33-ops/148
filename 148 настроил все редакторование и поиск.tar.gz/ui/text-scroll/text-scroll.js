(function () {
  function renderRow(el) {
    var checked = (el && el.dataset && el.dataset.noScroll === '1') ? ' checked' : '';
    return (
      '<div class="row">' +
        '<div>' +
          '<div class="label">Прокрутка</div>' +
          '<label class="cb"><input type="checkbox" id="pNoScroll"' + checked + '> Без скрола</label>' +
          '<div class="note">Экспорт и «опубликовано»: когда включено, весь текст показывается целиком, без внутреннего скролла. В редакторе текст по-прежнему обрезается по границам блока.</div>' +
        '</div>' +
      '</div>'
    );
  }

  function bind(el) {
    var input = document.querySelector('#pNoScroll');
    if (!input) return;
    input.addEventListener('change', function (e) {
      if (e.target.checked) { el.dataset.noScroll = '1'; }
      else { delete el.dataset.noScroll; }
    });
  }

  // Добавляет ряд в #props (если его ещё нет) и вешает обработчик
  function install(el) {
    if (!el || el.dataset.type !== 'text') return;
    var props = document.querySelector('#props');
    if (!props) return;
    if (!props.querySelector('#pNoScroll')) {
      props.insertAdjacentHTML('beforeend', renderRow(el));
    }
    bind(el);
  }

  window.TextScroll = { renderRow, bind, install };
})();
